export SPI_TB_DIR=${PWD}
